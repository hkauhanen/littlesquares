#' Temperature Hash
#'
#' A hash table to recover h from H(tau).
#'
#' Unlikely to be of use to the end-user, this hash is utilized by
#' the \code{\link{temperature}} and \code{\link{invert_H}} functions.
#' @name temperature_hash
#' @docType data
#' @format A data frame of 10000 rows and 2 columns:
#' \describe{
#' \item{\code{tau}}{tau}
#' \item{\code{Htau}}{H(tau)}
#' }
"temperature_hash"
