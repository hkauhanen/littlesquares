# dyntyp
Methods for dynamic typology
