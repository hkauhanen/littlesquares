# Install required packages. To be run on Konstanz SCC (GridEngine).

install.packages("ritwals_0.0.0.9003.tar.gz", repos=NULL, lib="./lib")
install.packages("hipster_0.0.0.9008.tar.gz", repos=NULL, lib="./lib")
