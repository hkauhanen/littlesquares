# required stuff
library(ritwals, lib.loc="./lib")
library(hipster, lib.loc="./lib")
load("newR/temperature_hash.RData")
source("newR/temperature.R")
source("newR/toolbox.R")
source("newR/sigmabias_permutation.R")

# command-line arguments from Condor submit script
args <- commandArgs(trailingOnly=TRUE)
job <- as.numeric(args[2])

# seed RNG
seed <- hipster::seed_seed(seed=2020+4, n=job)

# run
NN_hash <- read.csv("newR/wals-distances-100closest-nosign.csv")
res <- do.call(rbind, lapply(X=1:138, FUN=function(X) { df <- temperature(neighbourhood_size=10, id="44A", up=1, down=6, resample_size=0, bootstrap=FALSE, NN_hash=NN_hash, data=prep_data(n=X)); df$n <- X; df }))
res$rep <- job

# writeout
write.csv(res, file=paste("results/res", args[2], "csv", sep="."), row.names=FALSE)
