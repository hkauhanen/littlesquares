merge_with_dediu <- function(df,
                             neighbourhood_size,
                             dediufile = "../data/dediu-2010/binary.csv") {
  dediu <- read.csv(dediufile)
  names(dediu)[1] <- "feature_ID"

  df <- df[df$neighbourhood_size==neighbourhood_size, ]
  df <- aggregate(df[, 2:4], list(df$feature_ID), median, na.rm=TRUE)
  names(df)[1] <- "feature_ID"

  df <- merge(df, dediu, by="feature_ID")

  df
}


correlate_with_dediu <- function(df,
                                 neighbourhood_size,
                                 method = "spearman",
                                 no_of_knockouts = 0) {
  df <- merge_with_dediu(df, neighbourhood_size=neighbourhood_size)
  knockouts <- hipster::knockout_lm(df, PC1~temperature, id.var="feature_ID")
  knockouts <- knockouts[1:no_of_knockouts, ]
  df <- df[!(df$feature_ID %in% knockouts$knockee), ]
  
  print(knockouts)

  cor.test(df$temperature, df$PC1, method=method)
}


correlate_over_neighbourhood_size <- function(df,
                                              testee = 1,
                                              method = "spearman") {
  sizes <- unique(df$neighbourhood_size)
  out <- data.frame(neighbourhood_size=as.numeric(sizes), correlation=NA, p.value=NA)
  for (s in sizes) {
    df1 <- df[df$neighbourhood_size==testee, ]
    df1 <- aggregate(df1[, 2:4], list(df1$feature_ID), median, na.rm=TRUE)
    df2 <- df[df$neighbourhood_size==s, ]
    df2 <- aggregate(df2[, 2:4], list(df2$feature_ID), median, na.rm=TRUE)
    here <- cor.test(df1$temperature, df2$temperature, method=method)
    out[out$neighbourhood_size==s, ]$correlation <- here$estimate
    out[out$neighbourhood_size==s, ]$p.value <- here$p.value
  }
  out
}


figure_out_best_neighbourhood_size <- function(df,
                                               method = "spearman") {
  sizes <- unique(df$neighbourhood_size)
  bestcorsum <- -2
  best_size <- NA
  for (s in sizes) {
    here <- correlate_over_neighbourhood_size(df=df, testee=s, method=method)
    corsum <- sum(here$correlation)
    if (corsum > bestcorsum) {
      bestcorsum <- corsum
      best_size <- s
    }
  }
  best_size
}
