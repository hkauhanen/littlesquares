#!/bin/bash
cp ../../*.tar.gz .
rm -rf cpp
tar xzf cpp.tar.gz
rm -rf results
mkdir results
rm -rf errout
mkdir errout
rm -f *.tar.gz
