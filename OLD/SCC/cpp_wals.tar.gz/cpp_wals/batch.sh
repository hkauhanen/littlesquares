#!/bin/bash
cd cpp
./littlesquares-graph --iterations 12250000 --measurementphase 1 --graphfile input/WALS_neighbours_10closest.csv --voterrate 0.5 --parameterfile input/ingress_egress_rates.csv --taufile input/tau_hash.csv --branchingrate 0.0 --outfile ../results/res.cpp_wals.${1}.csv
cd ..
