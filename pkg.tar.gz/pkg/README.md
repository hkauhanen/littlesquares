# Contents

This folder contains R packages our analyses depend on.

* `hipster_0.0.0.9010.tar.gz`: Henri's Idiosyncratic Package for Somewhat Tedious Everyday Routines (see <https://github.com/hkauhanen/hipster> for details)
* `ritwals_0.0.0.9101.tar.gz`: R Interface to WALS; our data (see <https://hkauhanen.github.io/ritwals> for details)
