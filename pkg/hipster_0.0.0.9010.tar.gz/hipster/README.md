# hipster
Henri's Idiosyncratic Package for Somewhat Tedious Everyday Routines
