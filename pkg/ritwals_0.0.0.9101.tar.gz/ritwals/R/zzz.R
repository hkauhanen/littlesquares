utils::globalVariables(c("WALS", "WALS_features", "WALS_languages"))
