require(ggplot2)
require(ggrepel)


# Plot all the figures for the manuscript, including those that go in the
# appendices.
#
plot.all_for_paper <- function(folder) {
  # Main text

  # Appendices
}


# Plot "geo-scale correlations", i.e. correlations of tau when computed
# with neighbourhood sizes i and j. The "optimal" neighbourhood size
# i_opt is figured out first by taking that size j that maximizes the
# sum of Spearman correlation coefficients across all i. The correlation
# of temperatures between i and i_opt is then plotted.
#
plot.correlations_scale <- function(df) {
  scales <- sort(unique(df$neighbourhood_size))
  reps <- sort(unique(df$rep))

  # find optimal scale (in the sense that the sum of the Spearman
  # correlation coefficient across scales is maximized)
  testdf <- data.frame(testee=scales, cumulative_coefficient=NA)
  for (testee in scales) {
    out <- expand.grid(scale=scales, rep=reps, coefficient=NA, p=NA)
    for (i in 1:nrow(out)) {
      dfr <- df[df$rep==out[i,]$rep, ]
      df1 <- dfr[dfr$neighbourhood_size==testee, ]
      df2 <- dfr[dfr$neighbourhood_size==out[i,]$scale, ]
      cortest <- cor.test(df1$temperature, df2$temperature, method="spearman")
      out[i,]$coefficient <- cortest$estimate
      out[i,]$p <- cortest$p.value
    }
    testdf[testdf$testee==testee, ]$cumulative_coefficient <- sum(out$coefficient)
  }
  testdf <- testdf[order(testdf$cumulative_coefficient, decreasing=TRUE), ]
  best_testee <- testdf[1,]$testee

  # get correlations against best testee
  out <- expand.grid(scale=scales, rep=reps, coefficient=NA, p=NA)
  for (i in 1:nrow(out)) {
    dfr <- df[df$rep==out[i,]$rep, ]
    df1 <- dfr[dfr$neighbourhood_size==best_testee, ]
    df2 <- dfr[dfr$neighbourhood_size==out[i,]$scale, ]
    cortest <- cor.test(df1$temperature, df2$temperature, method="spearman")
    out[i,]$coefficient <- cortest$estimate
    out[i,]$p <- cortest$p.value
  }

  # plot
  ggplot(out, aes(x=factor(scale), y=coefficient)) + geom_boxplot(position="dodge")
}
