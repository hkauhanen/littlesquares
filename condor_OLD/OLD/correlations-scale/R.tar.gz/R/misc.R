print_condor_script_scale_correlations <- function(reps,
                                                   neighbourhood_sizes = seq(from=1, to=50, by=1),
                                                   outfile) {
  sink(outfile)
  out <- paste0("arguments = --vanilla --args $(Cluster) $(Process) ", neighbourhood_sizes)
  for (i in 1:length(out)) {
    cat(out[i]);
    cat("\n");
    cat(paste0("queue ", reps))
    cat("\n");
  }
}
