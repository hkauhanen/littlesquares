#!/bin/bash
rm -rf results
mkdir results
rm -rf errout
mkdir errout
rm -rf lib
mkdir lib
