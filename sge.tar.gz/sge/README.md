Scripts to deploy data analysis on an SGE parallel cluster. To start a job, navigate to the correct folder and:

```
sh preparations.sh
qsub submit.sh
```

Results will appear in the `results` subfolder.
