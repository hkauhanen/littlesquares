# Contents

* `tau-hash.csv`: Lookup table for converting between tau and H(tau)
* `unsilly-features.*`: List of WALS features we want to analyse
* `wals-distances-100closest.csv`: 100 nearest neighbours of all languages in WALS

The file `wals-distances-100closest.csv` is from <https://github.com/hkauhanen/wals-distances> (see the script there for its generation).
